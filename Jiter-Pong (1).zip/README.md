This is a jittery pong game. Made with P5.js

Replit link here: https://replit.com/@MohammadKherfan/Jiter-Pong?v=1